export class Serie {
    constructor(
        public titulo: string,
        public descripcion: string,
        public anio: number,
        public tipo: string,
        public imagen: string
    ) {}
}
