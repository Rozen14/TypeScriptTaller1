"use strict";
document.getElementsByTagName("h1")[0].innerHTML = "Hola desde Typescript";
